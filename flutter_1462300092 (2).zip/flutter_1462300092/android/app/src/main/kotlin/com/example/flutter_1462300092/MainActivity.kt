package com.example.flutter_1462300092

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
