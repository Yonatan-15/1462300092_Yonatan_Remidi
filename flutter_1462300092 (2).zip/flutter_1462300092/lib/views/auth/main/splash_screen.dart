import 'package:flutter/material.dart';
import 'package:provider/provider.provider.dart';
import '../../providers/auth_provider.dart';
import '../auth/login_page.dart';
import 'welcome_page.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _handleSession();
  }

  void _handleSession() async {
    // Berjalan dengan delay tepat 3 detik
    await Future.delayed(const Duration(seconds: 3));
    if (!mounted) return;

    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    bool isLoggedIn = await authProvider.checkLoginSession();

    if (isLoggedIn && authProvider.user != null) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const WelcomePage()));
    } else {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginPage()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.shopping_bag_outlined, size: 90, color: Colors.indigo), // Logo bertema E-Commerce
            SizedBox(height: 16),
            Text(
              'SpaceNews Core',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.indigo),
            ),
            SizedBox(height: 30),
            CircularProgressIndicator(), // Circular ProgressIndicator di tengah layar
          ],
        ),
      ),
    );
  }
}