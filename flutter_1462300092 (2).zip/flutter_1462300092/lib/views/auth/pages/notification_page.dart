import 'package:flutter/material.dart';

class NotificationPage extends StatelessWidget {
  const NotificationPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> staticNotifications = [
      {'title': 'Update Sistem Berhasil', 'body': 'SpaceNews core kini mendukung performa real-time sync.', 'date': '10 Menit yang lalu'},
      {'title': 'Rekomendasi Berita', 'body': 'Lihat perkembangan peluncuran roket Artemis terbaru hari ini.', 'date': '1 Jam yang lalu'},
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Notifications'), automaticImplyLeading: false),
      body: ListView.builder(
        itemCount: staticNotifications.length,
        itemBuilder: (context, index) {
          final notify = staticNotifications[index];
          return ListTile(
            leading: const CircleAvatar(child: Icon(Icons.notifications)),
            title: Text(notify['title']!, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(notify['body']!),
            trailing: Text(notify['date']!, style: const TextStyle(fontSize: 11)),
          );
        },
      ),
    );
  }
}