import 'package:flutter/material.dart';
// Removed provider dependency to fix missing package error

import '../../../providers/auth_provider.dart';
import '../login_page.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    // Mengambil data dari AuthProvider simulasi
    final authProvider = AuthProvider();
    final userData = authProvider.mockUserData;

    String name = userData?['name'] ?? "Nama Pengguna";
    String email = userData?['email'] ?? "email@domain.com";
    String instagram = userData?['instagram'] ?? "@instagram";

    return Scaffold(
      appBar: AppBar(title: const Text('Profile'), automaticallyImplyLeading: false),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircleAvatar(radius: 50, child: Icon(Icons.person, size: 55)),
              const SizedBox(height: 16),
              Text(name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              Text(email, style: const TextStyle(fontSize: 16, color: Colors.grey)),
              Text(instagram, style: const TextStyle(fontSize: 16, color: Colors.blue)),
              const SizedBox(height: 48),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white, minimumSize: const Size.fromHeight(50)),
                onPressed: () async {
                  // Use local authProvider instance instead of Provider to avoid package dependency
                  await authProvider.logout();
                  if (context.mounted) {
                    // Navigate to the named login route to avoid referencing LoginPage class directly
                    Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
                  }
                },
                child: const Text('Log Out'),
              )
            ],
          ),
        ),
      ),
    );
  }
}