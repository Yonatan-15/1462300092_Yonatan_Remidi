import 'package:flutter/material.dart';
import '../../../models/article_model.dart';

class DetailPage extends StatefulWidget {
  final Article article;
  const DetailPage({super.key, required this.article});

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  bool _isFavorited = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ruang Baca'),
        actions: [
          IconButton(
            icon: Icon(
              _isFavorited ? Icons.favorite : Icons.favorite_border,
              color: _isFavorited ? Colors.red : null,
            ),
            onPressed: () {
              setState(() => _isFavorited = !_isFavorited);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(_isFavorited 
                      ? 'Sukses menambahkan ke Favorit!' 
                      : 'Dihapus dari favorit')
                )
              );
            },
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(widget.article.imageUrl, width: double.infinity, height: 240, fit: BoxFit.cover),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.article.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('Sumber: ${widget.article.newsSite}', style: const TextStyle(fontStyle: FontStyle.italic, color: Colors.grey)),
                  const Divider(height: 32),
                  Text(
                    widget.article.summary,
                    style: const TextStyle(fontSize: 16, height: 1.5),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}