import 'dart:convert';
import 'dart:io';
import '../models/article_model.dart';

class ApiService {
  static const String _url = 'https://api.spaceflightnewsapi.net/v4/articles/?limit=20';

  Future<List<Article>> fetchArticles() async {
    final httpClient = HttpClient();

    try {
      final request = await httpClient.getUrl(Uri.parse(_url));
      final response = await request.close();

      if (response.statusCode == 200) {
        final body = await response.transform(utf8.decoder).join();
        final Map<String, dynamic> data = json.decode(body);
        final List<dynamic> results = data['results'];
        return results.map((json) => Article.fromJson(json)).toList();
      } else {
        throw Exception('Gagal memuat data dari server');
      }
    } catch (e) {
      throw Exception('Kesalahan jaringan: $e');
    } finally {
      httpClient.close(force: true);
    }
  }
}