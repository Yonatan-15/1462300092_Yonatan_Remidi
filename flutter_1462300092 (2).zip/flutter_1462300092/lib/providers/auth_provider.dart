import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthProvider with ChangeNotifier {
  Map<String, dynamic>? _mockUserData;
  bool _isLoggedIn = false;

  Map<String, dynamic>? get mockUserData => _mockUserData;

  // Memeriksa status sesi login dari lokal storage secara asinkronus
  Future<bool> checkLoginSession() async {
    final prefs = await SharedPreferences.getInstance();
    _isLoggedIn = prefs.getBool('isLoggedIn') ?? false;
    
    if (_isLoggedIn) {
      // PERBAIKAN SINTAKSIS: Menggunakan kutip ganda terluar agar interpolasi string aman
      _mockUserData = {
        'name': prefs.getString('savedName') ?? 'User 1462300092',
        'email': prefs.getString('savedEmail') ?? '1462300092@student.untag-sby.ac.id',
        'instagram': "@${(prefs.getString('savedName') ?? 'user').replaceAll(' ', '').toLowerCase()}"
      };
    }
    return _isLoggedIn;
  }

  // Simulasi pendaftaran kredensial akun pengguna ke local storage
  Future<void> register(String name, String email, String password) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('savedName', name);
    await prefs.setString('savedEmail', email);
    await prefs.setString('savedPassword', password);
    await Future.delayed(const Duration(milliseconds: 500));
  }

  // Simulasi proses otentikasi masuk halaman utama aplikasi
  Future<void> login(String email, String password) async {
    final prefs = await SharedPreferences.getInstance();
    String? savedEmail = prefs.getString('savedEmail');
    String? savedPassword = prefs.getString('savedPassword');

    // Validasi login (bisa menggunakan akun terdaftar atau kredensial default admin)
    if ((email == savedEmail && password == savedPassword) || (email == 'admin@gmail.com' && password == '123456')) {
      await prefs.setBool('isLoggedIn', true);
      if (savedEmail == null) {
        await prefs.setString('savedName', 'Mahasiswa Untag Surabaya');
        await prefs.setString('savedEmail', email);
      }
      await checkLoginSession();
      notifyListeners();
    } else {
      throw Exception('Kombinasi Email atau Password salah!');
    }
  }

  // Membersihkan seluruh tumpukan sesi aktif (Log Out)
  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isLoggedIn', false);
    _isLoggedIn = false;
    _mockUserData = null;
    notifyListeners();
  }

  // Simulasi pengiriman tautan pemulihan sandi lewat email
  Future<void> resetPassword(String email) async {
    await Future.delayed(const Duration(milliseconds: 500));
  }
}